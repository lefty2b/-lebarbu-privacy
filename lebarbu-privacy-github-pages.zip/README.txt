# Publier la politique de confidentialité avec GitHub Pages

1. Sur GitHub, crée un nouveau dépôt public nommé `lebarbu-privacy`.
2. Clique sur **Add file** puis **Upload files**.
3. Envoie les fichiers `index.html` et `style.css`.
4. Clique sur **Commit changes**.
5. Va dans **Settings** du dépôt.
6. Dans le menu de gauche, ouvre **Pages**.
7. Dans **Build and deployment**, choisis :
   - Source : **Deploy from a branch**
   - Branch : **main**
   - Folder : **/ (root)**
8. Clique sur **Save**.

Après quelques minutes, l'adresse devrait être :

https://lefty2b.github.io/lebarbu-privacy/

Copie cette adresse dans le champ « URL des règles de confidentialité » de Google Play Console.

Important : si l'application ajoute plus tard de la publicité, des statistiques,
un compte utilisateur, du multijoueur en ligne ou tout autre service tiers,
la politique devra être mise à jour.
